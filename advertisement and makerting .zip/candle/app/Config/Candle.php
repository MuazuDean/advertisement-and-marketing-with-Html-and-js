<?php namespace Config;

use CodeIgniter\Config\BaseConfig;

class Candle extends BaseConfig
{
    /**
     * Undocumented variable
     *
     * @var string
     * after registration 
     * it will be registered user's role_id
     */

    public $default_role  = '2';

}